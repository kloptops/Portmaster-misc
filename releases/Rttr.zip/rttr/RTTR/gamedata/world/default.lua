-- Copyright (C) 2005 - 2021 Settlers Freaks <sf-team at siedler25.org>
--
-- SPDX-License-Identifier: GPL-2.0-or-later

include "greenland.lua"
include "wasteland.lua"
include "winterworld.lua"
