# Open Fodder scripts

## Debugging

1. Install vscode extension 'koush.duk-debug'
2. Use the JS_Debug release of OpenFodder (https://s3.amazonaws.com/openfodder-builds/OpenFodder-Release_JSDebug-latest.zip) or compile with configuration 'Release_JSDebug'
3. start with OpenFodder --debugger
2. In VsCode, select debug with 'Duk Attach'

