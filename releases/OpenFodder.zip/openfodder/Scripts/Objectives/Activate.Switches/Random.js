
Objectives.ActivateSwitches.Random = function(pCount) {
	
	// TODO
};
