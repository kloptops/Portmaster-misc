
Objectives.RescueHostage.Random = function(pCount) {
	
	// TODO
};
