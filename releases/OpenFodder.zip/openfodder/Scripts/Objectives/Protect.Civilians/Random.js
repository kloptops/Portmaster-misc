
Objectives.ProtectCivilians.Random = function(pCount) {
	
	// TODO
};
