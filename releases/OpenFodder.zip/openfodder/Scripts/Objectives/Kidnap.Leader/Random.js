
Objectives.KidnapLeader.Random = function(pCount) {
	
	// TODO
};
