# Aquaria

# Controls

| Button            | Command                    |
|-------------------|----------------------------|
| **A**             | Mouse Left                 |
| **B**             | Mouse Right                |
| **R1**            | Slow down mouse            |
| **Start**         | ?????                      |
| **Select**        | ??????                     |
| **D-Pad**         | Mouse Movement             |
| **Left Analog**   | Mouse Movement             |


# Game folder structure

 
## Building


    git clone https://github.com/AquariaOSE/Aquaria.git

    cd Aquaria

    mkdir build

    cd build

    cmake ..

    make -j4

Doesnt currently work :D

# TODO:

- [ ] Get game to work.
- [ ] Figure out controls
- [ ] Make text a bit more readable if possible
- [ ] Test it on AmberELEC
- [ ] Test it on ArkOS

# Thanks

A special thanks to the excellent folks on the [PortMaster discord](https://discord.gg/m2QcSkMh).
