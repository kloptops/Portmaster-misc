-- Functions unused by game scripts; might be removed at some point

user_set_demo_intro = nil
user_save = nil
entity_slowToStopPath = nil
entity_isSlowingToStopPath = nil
entity_isNearGround = nil
entity_resumePath = nil
entity_move = nil
entity_toggleBone = nil
createSpore = nil
spawnAroundEntity = nil
node_isEntityPast = nil
entity_pathBurst = nil
avatar_clampPosition = nil
bedEffects = nil
entity_offsetUpdate = nil
avatar_updatePosition = nil
